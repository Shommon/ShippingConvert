document.addEventListener('DOMContentLoaded', function() {
  const modifyBtn = document.getElementById('modifyBtn');
  const status = document.getElementById('status');
  const oldWidthInput = document.getElementById('oldWidth');
  const newWidthInput = document.getElementById('newWidth');

  modifyBtn.addEventListener('click', async function() {
    try {
      const oldWidth = oldWidthInput.value.trim();
      const newWidth = newWidthInput.value.trim();
      
      if (!oldWidth || !newWidth) {
        throw new Error('Please enter both old and new width values');
      }

      // Get the active tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      // Execute script to modify HTML and open in new tab
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: modifyTableAndOpen,
        args: [oldWidth, newWidth]
      });

      const result = results[0].result;
      
      if (result.success) {
        status.innerHTML = `✅ Table modified! Width changed from ${oldWidth} to ${newWidth}<br>Opening in new tab...`;
        status.className = 'status success';
        
        // Clear status after 4 seconds
        setTimeout(() => {
          status.textContent = '';
          status.className = 'status';
        }, 4000);
      } else {
        throw new Error(result.error || 'Failed to modify table');
      }
    } catch (error) {
      console.error('Error modifying HTML:', error);
      status.textContent = '❌ Error: ' + error.message;
      status.className = 'status error';
      
      // Clear status after 5 seconds
      setTimeout(() => {
        status.textContent = '';
        status.className = 'status';
      }, 5000);
    }
  });
});

// Function that will be injected into the page
function modifyTableAndOpen(oldWidth, newWidth) {
  try {
    // Get the complete HTML including DOCTYPE
    const doctype = document.doctype ? 
      '<!DOCTYPE ' + document.doctype.name +
      (document.doctype.publicId ? ' PUBLIC "' + document.doctype.publicId + '"' : '') +
      (document.doctype.systemId ? ' "' + document.doctype.systemId + '"' : '') + 
      '>' : '';
    
    // Get the full HTML element
    const htmlElement = document.documentElement.outerHTML;
    let fullHTML = doctype + '\n' + htmlElement;
    
    // Find and modify the specific table
    // Look for table with the specific attributes and width
    const tableRegex = /<table[^>]*cellpadding="0"[^>]*cellspacing="0"[^>]*border="1"[^>]*style="[^"]*width:\s*784px[^"]*"[^>]*>/gi;
    
    let tableFound = false;
    fullHTML = fullHTML.replace(tableRegex, function(match) {
      tableFound = true;
      // Replace the width value in the style attribute
      return match.replace(/width:\s*784px/gi, `width: ${newWidth}`);
    });
    
    // If the regex approach didn't work, try a more general approach
    if (!tableFound) {
      // Look for any table with width: 784px in style
      const generalTableRegex = /<table([^>]*style="[^"]*width:\s*784px[^"]*"[^>]*>)/gi;
      fullHTML = fullHTML.replace(generalTableRegex, function(match, group1) {
        tableFound = true;
        return match.replace(/width:\s*784px/gi, `width: ${newWidth}`);
      });
    }
    
    // If still not found, try replacing any occurrence of width: 784px
    if (!tableFound) {
      const widthRegex = /width:\s*784px/gi;
      if (fullHTML.match(widthRegex)) {
        fullHTML = fullHTML.replace(widthRegex, `width: ${newWidth}`);
        tableFound = true;
      }
    }
    
    if (!tableFound) {
      return { success: false, error: 'Table with width 784px not found' };
    }
    
    // Store modified HTML in global variable for reference
    window.modifiedHTML = fullHTML;
    
    // Create a blob with the modified HTML
    const blob = new Blob([fullHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    
    // Open in new tab
    window.open(url, '_blank');
    
    // Log to console
    console.log('📄 Modified HTML stored in window.modifiedHTML');
    console.log(`🔧 Table width changed from ${oldWidth} to ${newWidth}`);
    
    return { success: true };
  } catch (error) {
    console.error('Error modifying HTML:', error);
    return { success: false, error: error.message };
  }
}