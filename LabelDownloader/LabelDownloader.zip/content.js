function modifyTableWidth() {
  // Find the target table by style width=784px
  const table = document.querySelector('table[style*="width: 784px"]');
  if (!table) {
    console.error("Target table not found.");
    return;
  }

  // Update the width
  table.style.width = "384px";
  console.log("✅ Table width changed to 384px");
}

// Run immediately when injected
modifyTableWidth();
